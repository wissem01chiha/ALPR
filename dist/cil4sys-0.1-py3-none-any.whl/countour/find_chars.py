"""
    find_chars.py 

    Function that gets possible coutours containing
    specific  arrangement of rectangular countours. 

    Args:
    -   countour_list           (List) 
    -   MAX_DIAG_MULTIPLYER     (float)
        MAX_ANGLE_DIFF          (float)
        MAX_AREA_DIFF           (float)
        MAX_WIDTH_DIFF          (float)
        MAX_HEIGHT_DIFF         (float)
        MIN_N_MATCHED           (float)

    Returns:
    -   matched_result_idx     (list)

©cil4sys  
"""

import numpy as np 

def find_chars(contour_list,MAX_DIAG_MULTIPLYER = 2,  
                            MAX_ANGLE_DIFF = 10.0, 
                            MAX_AREA_DIFF = 0.7, 
                            MAX_WIDTH_DIFF = 0.3,
                            MAX_HEIGHT_DIFF = 0.3,
                            MIN_N_MATCHED= 3 ):
    
    matched_result_idx = []
    for d1 in contour_list:
        matched_contours_idx = []
        for d2 in contour_list:
            if d1['idx'] == d2['idx']:
                continue

            dx = abs(d1['cx'] - d2['cx'])
            dy = abs(d1['cy'] - d2['cy'])

            diagonal_length1 = np.sqrt(d1['w'] ** 2 + d1['h'] ** 2)

            distance = np.linalg.norm(np.array([d1['cx'], d1['cy']]) - np.array([d2['cx'], d2['cy']]))
            if dx == 0:
                angle_diff = 90
            else:
                angle_diff = np.degrees(np.arctan(dy / dx))
            area_diff = abs(d1['w'] * d1['h'] - d2['w'] * d2['h']) / (d1['w'] * d1['h'])
            width_diff = abs(d1['w'] - d2['w']) / d1['w']
            height_diff = abs(d1['h'] - d2['h']) / d1['h']

            if distance < diagonal_length1 * MAX_DIAG_MULTIPLYER \
            and angle_diff < MAX_ANGLE_DIFF and area_diff < MAX_AREA_DIFF \
            and width_diff < MAX_WIDTH_DIFF and height_diff < MAX_HEIGHT_DIFF:
                matched_contours_idx.append(d2['idx'])

        # append this contour
        matched_contours_idx.append(d1['idx'])

        if len(matched_contours_idx) < MIN_N_MATCHED:
            continue

        matched_result_idx.append(matched_contours_idx)

    return matched_result_idx